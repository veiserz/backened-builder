const express = require('express');
const router = express.Router();

// Import all module routes here
// Example: const usersRoutes = require('./users');
// router.use('/users', usersRoutes);

router.get('/health', (req, res) => {
  res.json({ success: true, message: 'API is running' });
});

module.exports = router;

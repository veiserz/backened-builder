const {
  initializePool,
  PoolQuerier,
  executeQuery,
  executeQueryOne,
  executeCommand,
  executeTransaction,
  getPool,
  closePool,
} = require("./pg");

// Example: Basic SELECT
async function getActiveUsers() {
  const pool = getPool();
  const querier = new PoolQuerier(pool);
  const abortController = new AbortController();

  const users = await executeQuery(
    querier,
    abortController.signal,
    "SELECT * FROM users WHERE is_active = $1 LIMIT $2",
    [true, 10],
  );

  return users;
}

// Example: INSERT with Type Mapping
class User {
  constructor(row) {
    this.id = row.id;
    this.username = row.username;
    this.email = row.email;
    this.createdAt = new Date(row.created_at);
  }
}

async function createUser(username, email) {
  const querier = new PoolQuerier(getPool());
  const abortController = new AbortController();

  const user = await executeQueryOne(
    querier,
    abortController.signal,
    `INSERT INTO users (username, email) 
     VALUES ($1, $2) 
     RETURNING *`,
    [username, email],
    User,
  );

  return user;
}

// Example: Transaction
async function transferMoney(fromId, toId, amount) {
  const abortController = new AbortController();

  return await executeTransaction(abortController.signal, async (querier) => {
    // Debit
    await executeCommand(
      querier,
      abortController.signal,
      "UPDATE accounts SET balance = balance - $1 WHERE id = $2",
      [amount, fromId],
    );

    // Credit
    await executeCommand(
      querier,
      abortController.signal,
      "UPDATE accounts SET balance = balance + $1 WHERE id = $2",
      [amount, toId],
    );

    return { success: true };
  });
}

module.exports = {
  getActiveUsers,
  createUser,
  transferMoney,
};

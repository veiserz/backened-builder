/**
 * High-Performance PostgreSQL Database Wrapper
 * Simple API: db(query, args) and db.transaction()
 */

const { Pool } = require("pg");
const pgConfig = require("../../config/pg.config");
const { normalizeError, QueryCancelledError } = require("./errors");

// Global pool instance
let pool = null;

/**
 * DBQuerier Interface Definition
 */
class DBQuerier {
  async query(query, params) {
    throw new Error("Method not implemented");
  }
}

class PoolQuerier extends DBQuerier {
  constructor(pool) {
    super();
    this._pool = pool;
  }
  async query(query, params) {
    return await this._pool.query(query, params);
  }
}

class TransactionQuerier extends DBQuerier {
  constructor(client) {
    super();
    this._client = client;
  }
  async query(query, params) {
    return await this._client.query(query, params);
  }
}

/**
 * Initialize PostgreSQL connection pool
 */
async function initializePool() {
  if (pool) return pool;

  try {
    pool = new Pool({
      ...pgConfig.connection,
      ...pgConfig.pool,
    });

    pool.on("connect", (client) => {
      client.query(
        `SET statement_timeout = ${pgConfig.query.statement_timeout}`,
      );
    });

    pool.on("error", (err) => {
      console.error("💥 Unexpected database pool error:", err);
    });

    const client = await pool.connect();
    try {
      await client.query("SELECT NOW()");
      console.log("✅ PostgreSQL Pool Connected");
    } finally {
      client.release();
    }

    return pool;
  } catch (error) {
    console.error("❌ PostgreSQL Pool Connection Error:", error.message);
    throw normalizeError(error);
  }
}

async function closePool() {
  if (pool) {
    await pool.end();
    pool = null;
    console.log("✅ PostgreSQL Pool Closed");
  }
}

/**
 * Ensure pool is initialized before any operation
 */
function ensurePool() {
  if (!pool) {
    throw new Error("Database pool not initialized. Call db.init() first.");
  }
}

// =====================================================
// Core Execution Function
// =====================================================

async function executeQuery(sql, args, querier) {
  const dbQuerier = querier || new PoolQuerier(pool);
  const startTime = Date.now();

  try {
    const result = await dbQuerier.query(sql, args);
    const executionTime = Date.now() - startTime;

    // Log slow queries
    if (executionTime > pgConfig.query.slowQueryThreshold) {
      console.warn(`🐌 Slow Query Detected (${executionTime}ms):`, {
        query: sql.substring(0, 100),
        executionTime,
        rowCount: result.rowCount,
      });
    }

    return result;
  } catch (error) {
    const executionTime = Date.now() - startTime;

    console.error("💥 Query Execution Error:", {
      error: error.message,
      query: sql.substring(0, 100),
      executionTime,
      code: error.code,
    });

    throw normalizeError(error);
  }
}

// =====================================================
// Main db() Function
// =====================================================

/**
 * Execute SQL query
 *
 * @param {string} sql - SQL query with $1, $2, ... placeholders
 * @param {Array} [args=[]] - Query parameters
 * @returns {Promise<Array>} Query results (rows)
 *
 * @example
 * const users = await db('SELECT * FROM users WHERE active = $1', [true]);
 * const result = await db('INSERT INTO users (name) VALUES ($1) RETURNING *', ['John']);
 * await db('UPDATE users SET active = $1 WHERE id = $2', [false, 1]);
 * await db('DELETE FROM users WHERE id = $1', [userId]);
 */
async function db(sql, args = []) {
  ensurePool();
  const result = await executeQuery(sql, args, null);
  return result.rows || [];
}

// =====================================================
// Transaction Method
// =====================================================

/**
 * Execute Transaction with automatic ROLLBACK on error
 *
 * @param {Function} callback - Transaction callback (tx) => Promise
 * @returns {Promise<any>} Transaction result
 *
 * @example
 * const result = await db.transaction(async (tx) => {
 *   const user = await tx('INSERT INTO users (name) VALUES ($1) RETURNING *', ['John']);
 *   await tx('INSERT INTO profiles (user_id, bio) VALUES ($1, $2)', [user[0].id, 'Dev']);
 *   return user[0];
 * });
 */
db.Transaction = async function (callback) {
  ensurePool();

  const client = await pool.connect();
  let hasError = false;

  try {
    // Set transaction-level timeout
    await client.query(
      `SET statement_timeout = ${pgConfig.query.statement_timeout}`,
    );
    await client.query("BEGIN");

    const querier = new TransactionQuerier(client);

    // Create transaction function - does NOT double-normalize errors
    const tx = async (sql, args = []) => {
      const dbQuerier = querier;
      const startTime = Date.now();

      try {
        const result = await dbQuerier.query(sql, args);
        const executionTime = Date.now() - startTime;

        if (executionTime > pgConfig.query.slowQueryThreshold) {
          console.warn(`🐌 Slow Query in TX (${executionTime}ms):`, {
            query: sql.substring(0, 100),
            executionTime,
            rowCount: result.rowCount,
          });
        }

        return result.rows || [];
      } catch (error) {
        const executionTime = Date.now() - startTime;

        console.error("💥 TX Query Error:", {
          error: error.message,
          query: sql.substring(0, 100),
          executionTime,
          code: error.code,
        });

        // Throw normalized error ONCE
        throw normalizeError(error);
      }
    };

    const result = await callback(tx);

    await client.query("COMMIT");

    return result;
  } catch (error) {
    hasError = true;

    // Safe ROLLBACK - won't mask the original error
    try {
      await client.query("ROLLBACK");
    } catch (rollbackError) {
      console.error("💥 ROLLBACK failed:", rollbackError.message);
    }

    // Don't double-normalize if error is already normalized
    if (error.name && error.name.endsWith("Error") && error.code) {
      throw error;
    }
    throw normalizeError(error);
  } finally {
    // If error occurred, destroy the client instead of returning to pool
    // This prevents a potentially corrupted connection from being reused
    client.release(hasError);
  }
};

// =====================================================
// Initialization Methods
// =====================================================

db.init = initializePool;
db.close = closePool;

module.exports = db;

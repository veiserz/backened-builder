#!/bin/bash
MODULE_NAME=$1

if [ -z "$MODULE_NAME" ]; then
  echo "❌ Usage: ./make-module.sh <module_name>"
  echo "Example: ./make-module.sh users"
  exit 1
fi

# Capitalize first letter (user -> User)
CAP_NAME="$(tr '[:lower:]' '[:upper:]' <<< ${MODULE_NAME:0:1})${MODULE_NAME:1}"
DIR="src/modules/$MODULE_NAME"

if [ -d "$DIR" ]; then 
  echo "❌ Module '$MODULE_NAME' already exists!"
  exit 1
fi

mkdir -p "$DIR/middlewares"
echo "🚀 Creating module: $MODULE_NAME..."

# 1. DTO (Data Transfer Object / Validation)
cat <<EOD > "$DIR/$MODULE_NAME.dto.js"
const Joi = require('joi');

const create${CAP_NAME}Dto = Joi.object({
  title: Joi.string().required().min(3).max(100),
  description: Joi.string().optional().max(500),
  isActive: Joi.boolean().optional()
});

const update${CAP_NAME}Dto = Joi.object({
  title: Joi.string().optional().min(3).max(100),
  description: Joi.string().optional().max(500),
  isActive: Joi.boolean().optional()
});

module.exports = {
  create${CAP_NAME}Dto,
  update${CAP_NAME}Dto
};
EOD

# 2. Repository (Database Access Layer)
cat <<EOD > "$DIR/$MODULE_NAME.repository.js"
const ${CAP_NAME}Model = require('./${MODULE_NAME}.model');

class ${CAP_NAME}Repository {
  async findAll(filters = {}, options = {}) {
    const { page = 1, limit = 10, sort = '-createdAt' } = options;
    const skip = (page - 1) * limit;

    const items = await ${CAP_NAME}Model
      .find(filters)
      .sort(sort)
      .skip(skip)
      .limit(limit);

    const total = await ${CAP_NAME}Model.countDocuments(filters);

    return {
      items,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit)
      }
    };
  }

  async findById(id) {
    return await ${CAP_NAME}Model.findById(id);
  }

  async findOne(conditions) {
    return await ${CAP_NAME}Model.findOne(conditions);
  }

  async create(data) {
    const item = new ${CAP_NAME}Model(data);
    return await item.save();
  }

  async update(id, data) {
    return await ${CAP_NAME}Model.findByIdAndUpdate(
      id,
      { \$set: data },
      { new: true, runValidators: true }
    );
  }

  async delete(id) {
    return await ${CAP_NAME}Model.findByIdAndDelete(id);
  }

  async exists(conditions) {
    return await ${CAP_NAME}Model.exists(conditions);
  }
}

module.exports = new ${CAP_NAME}Repository();
EOD

# 3. Service (Business Logic)
cat <<EOD > "$DIR/$MODULE_NAME.service.js"
const ${MODULE_NAME}Repository = require('./${MODULE_NAME}.repository');

class ${CAP_NAME}Service {
  async getAll(filters = {}, options = {}) {
    return await ${MODULE_NAME}Repository.findAll(filters, options);
  }

  async getById(id) {
    const item = await ${MODULE_NAME}Repository.findById(id);
    if (!item) {
      const error = new Error('${CAP_NAME} not found');
      error.statusCode = 404;
      throw error;
    }
    return item;
  }

  async create(data) {
    // Business logic here (e.g., check duplicates)
    const exists = await ${MODULE_NAME}Repository.exists({ title: data.title });
    if (exists) {
      const error = new Error('${CAP_NAME} with this title already exists');
      error.statusCode = 409;
      throw error;
    }

    return await ${MODULE_NAME}Repository.create(data);
  }

  async update(id, data) {
    const item = await ${MODULE_NAME}Repository.update(id, data);
    if (!item) {
      const error = new Error('${CAP_NAME} not found');
      error.statusCode = 404;
      throw error;
    }
    return item;
  }

  async delete(id) {
    const item = await ${MODULE_NAME}Repository.delete(id);
    if (!item) {
      const error = new Error('${CAP_NAME} not found');
      error.statusCode = 404;
      throw error;
    }
    return item;
  }
}

module.exports = new ${CAP_NAME}Service();
EOD

# 4. Controller
cat <<EOD > "$DIR/$MODULE_NAME.controller.js"
const ${MODULE_NAME}Service = require('./${MODULE_NAME}.service');
const ApiResponse = require('../../common/utils/response');

class ${CAP_NAME}Controller {
  async getAll(req, res, next) {
    try {
      const filters = req.query.filters || {};
      const options = {
        page: parseInt(req.query.page) || 1,
        limit: parseInt(req.query.limit) || 10,
        sort: req.query.sort || '-createdAt'
      };

      const result = await ${MODULE_NAME}Service.getAll(filters, options);
      ApiResponse.success(res, result);
    } catch (error) {
      next(error);
    }
  }

  async getById(req, res, next) {
    try {
      const data = await ${MODULE_NAME}Service.getById(req.params.id);
      ApiResponse.success(res, data);
    } catch (error) {
      next(error);
    }
  }

  async create(req, res, next) {
    try {
      const data = await ${MODULE_NAME}Service.create(req.body);
      ApiResponse.created(res, data, '${CAP_NAME} created successfully');
    } catch (error) {
      next(error);
    }
  }

  async update(req, res, next) {
    try {
      const data = await ${MODULE_NAME}Service.update(req.params.id, req.body);
      ApiResponse.success(res, data, '${CAP_NAME} updated successfully');
    } catch (error) {
      next(error);
    }
  }

  async delete(req, res, next) {
    try {
      await ${MODULE_NAME}Service.delete(req.params.id);
      ApiResponse.success(res, null, '${CAP_NAME} deleted successfully');
    } catch (error) {
      next(error);
    }
  }
}

module.exports = new ${CAP_NAME}Controller();
EOD

# 5. Middleware (Module-specific)
cat <<EOD > "$DIR/middlewares/${MODULE_NAME}.middleware.js"
const ${MODULE_NAME}Repository = require('../${MODULE_NAME}.repository');

/**
 * Check if ${MODULE_NAME} exists
 */
const check${CAP_NAME}Exists = async (req, res, next) => {
  try {
    const id = req.params.id;
    const exists = await ${MODULE_NAME}Repository.exists({ _id: id });

    if (!exists) {
      return res.status(404).json({
        success: false,
        message: '${CAP_NAME} not found'
      });
    }

    next();
  } catch (error) {
    next(error);
  }
};

/**
 * Check ownership (example)
 */
const checkOwnership = async (req, res, next) => {
  try {
    const item = await ${MODULE_NAME}Repository.findById(req.params.id);

    // Example: check if user owns this resource
    // if (item.userId.toString() !== req.user.id) {
    //   return res.status(403).json({
    //     success: false,
    //     message: 'Access denied'
    //   });
    // }

    next();
  } catch (error) {
    next(error);
  }
};

module.exports = {
  check${CAP_NAME}Exists,
  checkOwnership
};
EOD

# 6. Routes
cat <<EOD > "$DIR/$MODULE_NAME.routes.js"
const express = require('express');
const router = express.Router();
const controller = require('./${MODULE_NAME}.controller');
const { authenticate } = require('../../common/middlewares/auth');
const validate = require('../../common/middlewares/validate');
const { check${CAP_NAME}Exists } = require('./middlewares/${MODULE_NAME}.middleware');
const { create${CAP_NAME}Dto, update${CAP_NAME}Dto } = require('./${MODULE_NAME}.dto');

// Routes
router.get('/', controller.getAll);
router.get('/:id', check${CAP_NAME}Exists, controller.getById);
router.post('/', validate(create${CAP_NAME}Dto), controller.create);
router.put('/:id', check${CAP_NAME}Exists, validate(update${CAP_NAME}Dto), controller.update);
router.delete('/:id', check${CAP_NAME}Exists, controller.delete);

module.exports = router;
EOD

# 7. Index (Module Export)
cat <<EOD > "$DIR/index.js"
module.exports = require('./${MODULE_NAME}.routes');
EOD

echo ""
echo "✅ Module '$MODULE_NAME' created successfully!"
echo ""
echo "📁 Generated files:"
echo "   ├── ${MODULE_NAME}.model.js         (Schema)"
echo "   ├── ${MODULE_NAME}.repository.js    (Data Access Layer)"
echo "   ├── ${MODULE_NAME}.service.js       (Business Logic)"
echo "   ├── ${MODULE_NAME}.controller.js    (HTTP Layer)"
echo "   ├── ${MODULE_NAME}.routes.js        (Routes)"
echo "   ├── middlewares/"
echo "   │   └── ${MODULE_NAME}.middleware.js (Custom Middleware)"
echo "   └── index.js                        (Module Export)"
echo ""
echo "📝 Next steps:"
echo "   1. Add to src/modules/index.js:"
echo "      const ${MODULE_NAME}Routes = require('./${MODULE_NAME}');"
echo "      router.use('/${MODULE_NAME}', ${MODULE_NAME}Routes);"
echo ""
echo "   2. Test your endpoidto.js           (Validation DTO)"
echo "   ├── ${MODULE_NAME}.nts:"
echo "      GET    /api/v1/${MODULE_NAME}"
echo "      GET    /api/v1/${MODULE_NAME}/:id"
echo "      POST   /api/v1/${MODULE_NAME}"
echo "      PUT    /api/v1/${MODULE_NAME}/:id"
echo "      DELETE /api/v1/${MODULE_NAME}/:id"
echo ""
